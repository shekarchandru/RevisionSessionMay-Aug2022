package com.gl.collectionsample;

public class Employee {
	
	String employeeId;
	String employeeName;
	String employeeAddress;
	double salary;
	
	public Employee() {
		super();
	}

	public Employee(String employeeId, String employeeName, String employeeAddress, double salary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeAddress="
				+ employeeAddress + ", salary=" + salary + "]";
	}
	
	
	

}
