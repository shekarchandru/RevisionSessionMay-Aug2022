package com.gl.collectionsample;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapSample {
	
	HashMap <Integer,Employee> employeeMap = new HashMap<Integer,Employee>();
	
	public void populateMap()
	{
		Employee e1 = new Employee("E001","Kiran","RTNagar",10000);
		Employee e2 = new Employee("E002","Rajesh","KRPuram",12000);
		Employee e3 = new Employee("E003","Suman","Koramangala",13000);
		Employee e4 = new Employee("E004","Mahesh","Vijayanagar",14000);
		Employee e5 = new Employee("E005","Rakesh","JayaNagar",15000);
		Employee e6 = new Employee("E006","Suresh","Malleswaram",15000);
		Employee e7 = new Employee("E006","Suresh","Malleswaram",15000);
		
		employeeMap.put(1, e1);
		employeeMap.put(2, e2);
		employeeMap.put(3, e3);
		employeeMap.put(4, e4);
		employeeMap.put(5, e5);
		employeeMap.put(5, e6);
		employeeMap.put(6, e6);
		employeeMap.put(7, e7);
		
		
		
	}
	public void fetchEmployeeMapElementsKeySet()
	{
		Set myKeys = employeeMap.keySet();
		Iterator <Integer> keyIter = myKeys.iterator();
		while(keyIter.hasNext())
		{
			Integer myKeyInts = keyIter.next();
			System.out.println("The Value for the Key "+myKeyInts+" is :"+employeeMap.get(myKeyInts));
		}
		
		
	}
	public void fetchEmployeeMapElementsEntrySet()
	{
		Set <Entry<Integer,Employee>> empEntrySet = employeeMap.entrySet();
		
		Iterator <Entry<Integer,Employee>> entrySetIter = empEntrySet.iterator();
		
		while(entrySetIter.hasNext())
		{
			Entry <Integer,Employee> empEntry = entrySetIter.next();
			Integer i = empEntry.getKey();
			Employee e = empEntry.getValue();
			System.out.println("Key "+i+" Value "+e);
		}
	}
	public static void main(String[] args)
	{
		HashMapSample hms = new HashMapSample();
		hms.populateMap();
		hms.fetchEmployeeMapElementsKeySet();
		System.out.println("----------");
		hms.fetchEmployeeMapElementsEntrySet();
	}

}
