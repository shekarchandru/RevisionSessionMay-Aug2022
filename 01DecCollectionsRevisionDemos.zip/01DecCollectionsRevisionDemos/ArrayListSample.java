package com.gl.collectionsample;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListSample {
	
	ArrayList myList;  
	ArrayList <Employee> employees = new ArrayList<Employee>();
//	List <Employee> employees1 = new ArrayList<Employee>();

	public void populateArrayList()
	{
		//Integer Double Not int
		myList = new ArrayList();
		myList.add("Harsha");
		myList.add(10000);
		myList.add(2000.456);
		myList.add(true);
		
	}
	public void populateEmployees()
	{
		Employee e1 = new Employee("E001","Kiran","RTNagar",10000);
		Employee e2 = new Employee("E002","Rajesh","KRPuram",12000);
		Employee e3 = new Employee("E003","Suman","Koramangala",13000);
		Employee e4 = new Employee("E004","Mahesh","Vijayanagar",14000);
		Employee e5 = new Employee("E005","Rakesh","JayaNagar",15000);
		
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		employees.add(e4);
		employees.add(e5);
		
		Employee e6 = new Employee("E006","Suresh","Malleswaram",15000);
		
		employees.add(2, e6);
		
		
		
	}
	public void fetchEmployeesFromAList()
	{
		Iterator <Employee> empIter = employees.iterator();
		while(empIter.hasNext())
		{
			//Employee emp1 = (Employee)empIter.next();
			Employee emp1 = empIter.next();
			System.out.println(emp1);
		}
		
	}
	public void fetchArrayListElements()
	{
		Iterator listIter = myList.iterator();
		while(listIter.hasNext())
		{
			Object o = listIter.next();
			System.out.println("The Object is "+o);
		}
	}
	public static void main(String[] args)
	{
		ArrayListSample als = new ArrayListSample();
	/*	als.populateArrayList();
		als.fetchArrayListElements();*/
		als.populateEmployees();
		als.fetchEmployeesFromAList();
		
	}

}
