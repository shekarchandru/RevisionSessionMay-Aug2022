package com.gl.collectionsample;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class HashSetTreeSet {

	HashSet <String> hs = new HashSet<String>();
	TreeSet <String> ts = new TreeSet<String>();
	
	public void populateHasSet()
	{
		hs.add("Chennai");
		hs.add("Gurugram");
		hs.add("Ernakulam");
		hs.add("Delhi");
		hs.add("Ahmedabad");
		hs.add("Faridabad");
		hs.add("Faridabad");
	}
	public void populateTreeSet()
	{
		ts.add("Chennai");
		ts.add("Gurugram");
		ts.add("Ernakulam");
		ts.add("Delhi");
		ts.add("Ahmedabad");
		ts.add("Faridabad");
		ts.add("Faridabad");
	}
	public void fetchHashSet()
	{
			Iterator <String> hsIter = hs.iterator();
			while(hsIter.hasNext())
			{
				String cityHs = hsIter.next();
				System.out.println("The City in HashSet is "+cityHs);
			}
		
	}
	public void fetchTreeSet()
	{
		Iterator <String> tsIter = ts.iterator();
		while(tsIter.hasNext())
		{
			String cityTs = tsIter.next();
			System.out.println("The City in TreeSet is "+cityTs);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSetTreeSet hsts = new HashSetTreeSet();
		hsts.populateHasSet();
		hsts.fetchHashSet();
		System.out.println("----------------------------------------------");
		hsts.populateTreeSet();
		hsts.fetchTreeSet();

	}

}
